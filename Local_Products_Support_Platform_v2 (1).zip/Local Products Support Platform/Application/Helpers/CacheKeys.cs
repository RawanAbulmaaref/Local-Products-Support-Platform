namespace Local_Products_Support_Platform.Application.Helpers
{
    public static class CacheKeys
    {
        public static string ProductById(int id) => $"product:{id}";
    }
}
