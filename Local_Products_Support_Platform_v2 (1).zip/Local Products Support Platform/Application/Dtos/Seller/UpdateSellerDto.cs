using System.ComponentModel.DataAnnotations;

namespace Local_Products_Support_Platform.Application.Dtos.Seller
{
    public class UpdateSellerDto
    {
        [MaxLength(100)]
        public string? SellerName { get; set; }
        [EmailAddress]
        [MaxLength(50)]
        public string? SellerEmail { get; set; }
        [Required]
        [MaxLength(14)]
        public string SellerPhone { get; set; } = string.Empty;
        [Required]
        [MaxLength(100)]
        public string SellerAddress { get; set; } = string.Empty;
    }
}
