namespace Local_Products_Support_Platform.Application.Dtos.Seller
{
    public class SellerDto
    {
        public int SellerId { get; set; }
        public string? SellerName { get; set; }
        public string? SellerEmail { get; set; }
        public string SellerPhone { get; set; } = string.Empty;
        public string SellerAddress { get; set; } = string.Empty;
    }
}
