namespace Local_Products_Support_Platform.Application.Dtos.Buyer
{
    public class BuyerDto
    {
        public int BuyerId { get; set; }
        public string? BuyerName { get; set; }
        public string? BuyerEmail { get; set; }
        public string BuyerPhone { get; set; } = string.Empty;
    }
}
