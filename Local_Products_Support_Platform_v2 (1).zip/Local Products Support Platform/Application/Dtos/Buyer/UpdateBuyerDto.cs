using System.ComponentModel.DataAnnotations;

namespace Local_Products_Support_Platform.Application.Dtos.Buyer
{
    public class UpdateBuyerDto
    {
        [MaxLength(100)]
        public string? BuyerName { get; set; }
        [EmailAddress]
        [MaxLength(50)]
        public string? BuyerEmail { get; set; }
        [Required]
        [MaxLength(14)]
        public string BuyerPhone { get; set; } = string.Empty;
    }
}
