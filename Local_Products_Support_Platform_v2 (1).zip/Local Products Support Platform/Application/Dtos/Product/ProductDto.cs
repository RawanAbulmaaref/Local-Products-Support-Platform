namespace Local_Products_Support_Platform.Application.Dtos.Product
{
    public class ProductDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public int SellerId { get; set; }
    }
}
