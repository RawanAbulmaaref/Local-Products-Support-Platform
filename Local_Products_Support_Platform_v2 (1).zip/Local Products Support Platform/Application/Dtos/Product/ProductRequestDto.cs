using System.ComponentModel.DataAnnotations;

namespace Local_Products_Support_Platform.Application.Dtos.Product
{
    public abstract class ProductRequestDto
    {
        [Required]
        [MaxLength(100)]
        public string ProductName { get; set; } = string.Empty;

        [Range(typeof(decimal), "1", "1000000")]
        public decimal Price { get; set; }

        public int SellerId { get; set; }
    }
}
