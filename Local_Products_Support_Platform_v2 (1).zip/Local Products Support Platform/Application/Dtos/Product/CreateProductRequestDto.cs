namespace Local_Products_Support_Platform.Application.Dtos.Product
{
    public class CreateProductRequestDto : ProductRequestDto
    {
    }
}
