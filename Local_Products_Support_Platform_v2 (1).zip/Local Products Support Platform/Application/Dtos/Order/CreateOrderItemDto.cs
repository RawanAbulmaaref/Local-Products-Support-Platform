using System.ComponentModel.DataAnnotations;

namespace Local_Products_Support_Platform.Application.Dtos.Order
{
    public class CreateOrderItemDto
    {
        [Required]
        public int ProductId { get; set; }
        [Range(1, 1000)]
        public int Quantity { get; set; }
    }
}
