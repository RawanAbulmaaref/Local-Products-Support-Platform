using System.ComponentModel.DataAnnotations;

namespace Local_Products_Support_Platform.Application.Dtos.Order
{
    public class CreateOrderDto
    {
        [Required]
        public int BuyerId { get; set; }
        [Required]
        public List<CreateOrderItemDto> Items { get; set; } = new List<CreateOrderItemDto>();
    }
}
