namespace Local_Products_Support_Platform.Application.Dtos.Order
{
    public class OrderDto
    {
        public int OrderId { get; set; }
        public decimal Totalprice { get; set; }
        public DateTime Orderdate { get; set; }
        public string Orderstatus { get; set; } = string.Empty;
        public int BuyerId { get; set; }
        public List<OrderItemDto> OrderItems { get; set; } = new List<OrderItemDto>();
    }
}
