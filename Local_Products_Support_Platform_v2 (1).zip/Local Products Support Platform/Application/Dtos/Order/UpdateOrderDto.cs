using System.ComponentModel.DataAnnotations;

namespace Local_Products_Support_Platform.Application.Dtos.Order
{
    public class UpdateOrderDto
    {
        [Required]
        [MaxLength(10)]
        public string Orderstatus { get; set; } = string.Empty;
    }
}
