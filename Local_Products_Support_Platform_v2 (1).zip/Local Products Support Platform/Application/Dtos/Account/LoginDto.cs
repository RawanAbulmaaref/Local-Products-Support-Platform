using System.ComponentModel.DataAnnotations;

namespace Local_Products_Support_Platform.Application.Dtos.Account
{
    public class LoginDto
    {
        [Required]
        public string Username { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty;
    }
}
