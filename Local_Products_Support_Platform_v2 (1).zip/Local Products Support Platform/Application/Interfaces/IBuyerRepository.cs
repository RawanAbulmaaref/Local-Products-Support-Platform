using Local_Products_Support_Platform.Domain.Entities.Models;

namespace Local_Products_Support_Platform.Application.Interfaces
{
    public interface IBuyerRepository
    {
        Task<List<Buyer>> GetAllAsync();
        Task<Buyer?> GetByIdAsync(int id);
        Task<Buyer> CreateAsync(Buyer buyerModel);
        Task<Buyer?> UpdateAsync(int id, Buyer buyerModel);
        Task<Buyer?> DeleteAsync(int id);
        Task<bool> BuyerExists(int id);
    }
}
