using Local_Products_Support_Platform.Domain.Entities.Models;

namespace Local_Products_Support_Platform.Application.Interfaces
{
    public interface ISellerRepository
    {
        Task<List<Seller>> GetAllAsync();
        Task<Seller?> GetByIdAsync(int id);
        Task<Seller> CreateAsync(Seller sellerModel);
        Task<Seller?> UpdateAsync(int id, Seller sellerModel);
        Task<Seller?> DeleteAsync(int id);
        Task<bool> SellerExists(int id);
    }
}
