using Local_Products_Support_Platform.Domain.Entities.Models;

namespace Local_Products_Support_Platform.Application.Interfaces
{
    public interface IOrderRepository
    {
        Task<List<Order>> GetAllAsync(int? buyerId = null);
        Task<Order?> GetByIdAsync(int id);
        Task<Order> CreateAsync(Order orderModel);
        Task<Order?> UpdateAsync(int id, Order orderModel);
        Task<Order?> DeleteAsync(int id);
    }
}
