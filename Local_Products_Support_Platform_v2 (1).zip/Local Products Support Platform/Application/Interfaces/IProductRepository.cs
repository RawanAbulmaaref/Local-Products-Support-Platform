using Local_Products_Support_Platform.Application.Helpers;
using Local_Products_Support_Platform.Domain.Entities.Models;

namespace Local_Products_Support_Platform.Application.Interfaces
{
    public interface IProductRepository
    {
        Task<List<Product>> GetAllAsync(QueryObject query);
        Task<List<Product>> GetBySellerIdAsync(int sellerId);
        Task<Product?> GetByIdAsync(int id);
        Task<Product> CreateAsync(Product productModel);
        Task<Product?> UpdateAsync(int id, Product productModel);
        Task<Product?> DeleteAsync(int id);
    }
}
