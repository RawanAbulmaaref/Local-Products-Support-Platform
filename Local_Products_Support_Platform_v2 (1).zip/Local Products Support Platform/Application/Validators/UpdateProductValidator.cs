using Local_Products_Support_Platform.Application.Dtos.Product;

namespace Local_Products_Support_Platform.Application.Validators
{
    public class UpdateProductValidator : ProductRequestValidator<UpdateProductRequestDto>
    {
    }
}
