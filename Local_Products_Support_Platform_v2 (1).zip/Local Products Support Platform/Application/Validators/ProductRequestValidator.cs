using Local_Products_Support_Platform.Application.Dtos.Product;
using FluentValidation;

namespace Local_Products_Support_Platform.Application.Validators
{
    public abstract class ProductRequestValidator<T> : AbstractValidator<T>
        where T : ProductRequestDto
    {
        protected ProductRequestValidator()
        {
            RuleFor(x => x.ProductName)
                .NotEmpty().WithMessage("Product name is required")
                .MaximumLength(100);

            RuleFor(x => x.Price)
                .GreaterThanOrEqualTo(1).WithMessage("Price must be at least 1")
                .LessThanOrEqualTo(1000000);

            RuleFor(x => x.SellerId)
                .GreaterThan(0).WithMessage("SellerId is required");
        }
    }
}
