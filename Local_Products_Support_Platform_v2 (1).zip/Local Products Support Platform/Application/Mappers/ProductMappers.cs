using Local_Products_Support_Platform.Application.Dtos.Product;
using Local_Products_Support_Platform.Domain.Entities.Models;

namespace Local_Products_Support_Platform.Application.Mappers
{
    public static class ProductMappers
    {
        public static ProductDto ToProductDto(this Product productModel)
        {
            return new ProductDto
            {
                ProductId = productModel.ProductId,
                ProductName = productModel.ProductName,
                Price = productModel.Price,
                SellerId = productModel.SellerId
            };
        }

        public static Product ToProductFromCreateDto(this CreateProductRequestDto productDto)
        {
            return new Product
            {
                ProductName = productDto.ProductName,
                Price = productDto.Price,
                SellerId = productDto.SellerId
            };
        }

        public static Product ToProductFromUpdateDto(this UpdateProductRequestDto productDto)
        {
            return new Product
            {
                ProductName = productDto.ProductName,
                Price = productDto.Price,
                SellerId = productDto.SellerId
            };
        }
    }
}
