using Local_Products_Support_Platform.Application.Dtos.Seller;
using Local_Products_Support_Platform.Domain.Entities.Models;

namespace Local_Products_Support_Platform.Application.Mappers
{
    public static class SellerMappers
    {
        public static SellerDto ToSellerDto(this Seller sellerModel)
        {
            return new SellerDto
            {
                SellerId = sellerModel.SellerId,
                SellerName = sellerModel.SellerName,
                SellerEmail = sellerModel.SellerEmail,
                SellerPhone = sellerModel.SellerPhone,
                SellerAddress = sellerModel.SellerAddress
            };
        }

        public static Seller ToSellerFromCreate(this CreateSellerDto sellerDto)
        {
            return new Seller
            {
                SellerName = sellerDto.SellerName,
                SellerEmail = sellerDto.SellerEmail,
                SellerPhone = sellerDto.SellerPhone,
                SellerAddress = sellerDto.SellerAddress
            };
        }

        public static Seller ToSellerFromUpdate(this UpdateSellerDto sellerDto)
        {
            return new Seller
            {
                SellerName = sellerDto.SellerName,
                SellerEmail = sellerDto.SellerEmail,
                SellerPhone = sellerDto.SellerPhone,
                SellerAddress = sellerDto.SellerAddress
            };
        }
    }
}
