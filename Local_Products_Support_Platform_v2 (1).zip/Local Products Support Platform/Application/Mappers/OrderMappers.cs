using Local_Products_Support_Platform.Application.Dtos.Order;
using Local_Products_Support_Platform.Domain.Entities.Models;

namespace Local_Products_Support_Platform.Application.Mappers
{
    public static class OrderMappers
    {
        public static OrderDto ToOrderDto(this Order orderModel)
        {
            return new OrderDto
            {
                OrderId = orderModel.OrderId,
                Totalprice = orderModel.Totalprice,
                Orderdate = orderModel.Orderdate,
                Orderstatus = orderModel.Orderstatus,
                BuyerId = orderModel.BuyerId,
                OrderItems = orderModel.OrderItems.Select(i => new OrderItemDto
                {
                    OrderItemId = i.OrderItemId,
                    ProductId = i.ProductId,
                    Quantity = i.Quantity,
                    UnitPrice = i.UnitPrice
                }).ToList()
            };
        }
    }
}
