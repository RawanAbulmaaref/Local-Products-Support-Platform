using Local_Products_Support_Platform.Application.Dtos.Buyer;
using Local_Products_Support_Platform.Domain.Entities.Models;

namespace Local_Products_Support_Platform.Application.Mappers
{
    public static class BuyerMappers
    {
        public static BuyerDto ToBuyerDto(this Buyer buyerModel)
        {
            return new BuyerDto
            {
                BuyerId = buyerModel.BuyerId,
                BuyerName = buyerModel.BuyerName,
                BuyerEmail = buyerModel.BuyerEmail,
                BuyerPhone = buyerModel.BuyerPhone
            };
        }

        public static Buyer ToBuyerFromCreate(this CreateBuyerDto buyerDto)
        {
            return new Buyer
            {
                BuyerName = buyerDto.BuyerName,
                BuyerEmail = buyerDto.BuyerEmail,
                BuyerPhone = buyerDto.BuyerPhone
            };
        }

        public static Buyer ToBuyerFromUpdate(this UpdateBuyerDto buyerDto)
        {
            return new Buyer
            {
                BuyerName = buyerDto.BuyerName,
                BuyerEmail = buyerDto.BuyerEmail,
                BuyerPhone = buyerDto.BuyerPhone
            };
        }
    }
}
