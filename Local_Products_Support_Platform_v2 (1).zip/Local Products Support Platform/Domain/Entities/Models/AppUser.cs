using Microsoft.AspNetCore.Identity;

namespace Local_Products_Support_Platform.Domain.Entities.Models
{
    public class AppUser : IdentityUser
    {
    }
}
