using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Local_Products_Support_Platform.Domain.Entities.Models
{
    [Table("Orders")]
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Totalprice { get; set; }

        public DateTime Orderdate { get; set; } = DateTime.Now;

        [Required]
        [MaxLength(10)]
        public string Orderstatus { get; set; } = string.Empty;

        public int BuyerId { get; set; }

        [ForeignKey(nameof(BuyerId))]
        public Buyer? Buyer { get; set; }

        public List<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }
}
