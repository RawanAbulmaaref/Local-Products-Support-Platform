using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Local_Products_Support_Platform.Domain.Entities.Models
{
    [Table("Buyers")]
    public class Buyer
    {
        [Key]
        public int BuyerId { get; set; }

        [MaxLength(100)]
        public string? BuyerName { get; set; }

        [MaxLength(50)]
        public string? BuyerEmail { get; set; }

        [Required]
        [MaxLength(14)]
        public string BuyerPhone { get; set; } = string.Empty;

        public bool IsDelete { get; set; } = false;

        public List<Order> Orders { get; set; } = new List<Order>();
    }
}
