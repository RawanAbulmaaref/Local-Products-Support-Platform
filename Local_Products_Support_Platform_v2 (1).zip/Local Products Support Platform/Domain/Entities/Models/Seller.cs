using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Local_Products_Support_Platform.Domain.Entities.Models
{
    [Table("Sellers")]
    public class Seller
    {
        [Key]
        public int SellerId { get; set; }

        [MaxLength(100)]
        public string? SellerName { get; set; }

        [MaxLength(50)]
        public string? SellerEmail { get; set; }

        [Required]
        [MaxLength(14)]
        public string SellerPhone { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string SellerAddress { get; set; } = string.Empty;

        public bool IsDelete { get; set; } = false;

        public List<Product> Products { get; set; } = new List<Product>();
    }
}
