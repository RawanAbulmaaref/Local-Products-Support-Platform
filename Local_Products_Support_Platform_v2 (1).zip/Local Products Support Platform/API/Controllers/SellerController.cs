using Local_Products_Support_Platform.Application.Dtos.Seller;
using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Application.Mappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Local_Products_Support_Platform.API.Controllers
{
    [Route("api/seller")]
    [ApiController]
    public class SellerController : ControllerBase
    {
        private readonly ISellerRepository _sellerRepo;

        public SellerController(ISellerRepository sellerRepo)
        {
            _sellerRepo = sellerRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var sellers = await _sellerRepo.GetAllAsync();
            var sellerDtos = sellers.Select(s => s.ToSellerDto()).ToList();
            return Ok(sellerDtos);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById([FromRoute] int id)
        {
            var seller = await _sellerRepo.GetByIdAsync(id);

            if (seller == null)
            {
                return NotFound();
            }

            return Ok(seller.ToSellerDto());
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Create([FromBody] CreateSellerDto sellerDto)
        {
            var sellerModel = sellerDto.ToSellerFromCreate();
            await _sellerRepo.CreateAsync(sellerModel);
            return CreatedAtAction(nameof(GetById), new { id = sellerModel.SellerId }, sellerModel.ToSellerDto());
        }

        [HttpPut("{id:int}")]
        [Authorize]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] UpdateSellerDto sellerDto)
        {
            var seller = await _sellerRepo.UpdateAsync(id, sellerDto.ToSellerFromUpdate());

            if (seller == null)
            {
                return NotFound();
            }

            return Ok(seller.ToSellerDto());
        }

        [HttpDelete("{id:int}")]
        [Authorize]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            var seller = await _sellerRepo.DeleteAsync(id);

            if (seller == null)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
