using Local_Products_Support_Platform.Application.Dtos.Order;
using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Application.Mappers;
using Local_Products_Support_Platform.Domain.Entities.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Local_Products_Support_Platform.API.Controllers
{
    [Route("api/order")]
    [ApiController]
    [Authorize]
    public class OrderController : ControllerBase
    {
        private readonly IOrderRepository _orderRepo;
        private readonly IBuyerRepository _buyerRepo;
        private readonly IProductRepository _productRepo;

        public OrderController(IOrderRepository orderRepo, IBuyerRepository buyerRepo, IProductRepository productRepo)
        {
            _orderRepo = orderRepo;
            _buyerRepo = buyerRepo;
            _productRepo = productRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] int? buyerId)
        {
            var orders = await _orderRepo.GetAllAsync(buyerId);
            return Ok(orders.Select(o => o.ToOrderDto()));
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById([FromRoute] int id)
        {
            var order = await _orderRepo.GetByIdAsync(id);

            if (order == null)
            {
                return NotFound();
            }

            return Ok(order.ToOrderDto());
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateOrderDto orderDto)
        {
            if (!await _buyerRepo.BuyerExists(orderDto.BuyerId))
                return BadRequest("Buyer does not exist");

            var orderModel = new Order
            {
                BuyerId = orderDto.BuyerId,
                Orderstatus = "Pending"
            };

            foreach (var item in orderDto.Items)
            {
                var product = await _productRepo.GetByIdAsync(item.ProductId);

                if (product == null)
                    return BadRequest("Product " + item.ProductId + " does not exist");

                orderModel.OrderItems.Add(new OrderItem
                {
                    ProductId = product.ProductId,
                    Quantity = item.Quantity,
                    UnitPrice = product.Price
                });

                orderModel.Totalprice += product.Price * item.Quantity;
            }

            await _orderRepo.CreateAsync(orderModel);

            return CreatedAtAction(nameof(GetById), new { id = orderModel.OrderId }, orderModel.ToOrderDto());
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] UpdateOrderDto orderDto)
        {
            var order = await _orderRepo.UpdateAsync(id, new Order { Orderstatus = orderDto.Orderstatus });

            if (order == null)
            {
                return NotFound();
            }

            return Ok(order.ToOrderDto());
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            var order = await _orderRepo.DeleteAsync(id);

            if (order == null)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
