using Local_Products_Support_Platform.Application.Dtos.Buyer;
using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Application.Mappers;
using Local_Products_Support_Platform.Domain.Constants;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Local_Products_Support_Platform.API.Controllers
{
    [Route("api/buyer")]
    [ApiController]
    public class BuyerController : ControllerBase
    {
        private readonly IBuyerRepository _buyerRepo;

        public BuyerController(IBuyerRepository buyerRepo)
        {
            _buyerRepo = buyerRepo;
        }

        [Authorize(Roles = AppRoles.SuperAdmin)]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var buyers = await _buyerRepo.GetAllAsync();
            return Ok(buyers.Select(b => b.ToBuyerDto()));
        }

        [HttpGet("{id:int}")]
        [Authorize]
        public async Task<IActionResult> GetById([FromRoute] int id)
        {
            var buyer = await _buyerRepo.GetByIdAsync(id);

            if (buyer == null)
            {
                return NotFound();
            }

            return Ok(buyer.ToBuyerDto());
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Create([FromBody] CreateBuyerDto buyerDto)
        {
            var buyerModel = buyerDto.ToBuyerFromCreate();
            await _buyerRepo.CreateAsync(buyerModel);
            return CreatedAtAction(nameof(GetById), new { id = buyerModel.BuyerId }, buyerModel.ToBuyerDto());
        }

        [HttpPut("{id:int}")]
        [Authorize]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] UpdateBuyerDto buyerDto)
        {
            var buyer = await _buyerRepo.UpdateAsync(id, buyerDto.ToBuyerFromUpdate());

            if (buyer == null)
            {
                return NotFound("Buyer not found");
            }

            return Ok(buyer.ToBuyerDto());
        }

        [HttpDelete("{id:int}")]
        [Authorize]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            var buyer = await _buyerRepo.DeleteAsync(id);

            if (buyer == null)
            {
                return NotFound("Buyer not found");
            }

            return NoContent();
        }
    }
}
