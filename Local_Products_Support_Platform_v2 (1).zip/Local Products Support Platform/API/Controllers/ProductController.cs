using Asp.Versioning;
using Local_Products_Support_Platform.API.Filters;
using Local_Products_Support_Platform.Application.Dtos.Product;
using Local_Products_Support_Platform.Application.Helpers;
using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Application.Mappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;

namespace Local_Products_Support_Platform.API.Controllers
{
    [Route("api/product")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepo;
        private readonly ISellerRepository _sellerRepo;
        private readonly ILogger<ProductController> _logger;
        private readonly IMemoryCache _cache;

        public ProductController(IProductRepository productRepo, ISellerRepository sellerRepo, ILogger<ProductController> logger, IMemoryCache cache)
        {
            _productRepo = productRepo;
            _sellerRepo = sellerRepo;
            _logger = logger;
            _cache = cache;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] QueryObject query)
        {
            var products = await _productRepo.GetAllAsync(query);
            var productDtos = products.Select(p => p.ToProductDto()).ToList();
            return Ok(productDtos);
        }

        [ApiVersion(1.0)]
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById([FromRoute] int id)
        {
            var cacheKey = CacheKeys.ProductById(id);
            if (_cache.TryGetValue(cacheKey, out ProductDto? cachedProduct))
            {
                _logger.LogInformation("Cache Hit {CacheKey}", cacheKey);
                return Ok(cachedProduct);
            }

            var product = await _productRepo.GetByIdAsync(id);

            if (product == null)
            {
                _logger.LogWarning("Product {ProductId} not found", id);
                return NotFound();
            }

            var productDto = product.ToProductDto();
            _cache.Set(cacheKey, productDto, TimeSpan.FromMinutes(1));

            return Ok(productDto);
        }

        [HttpGet("seller/{sellerId:int}")]
        public async Task<IActionResult> GetBySeller([FromRoute] int sellerId)
        {
            var products = await _productRepo.GetBySellerIdAsync(sellerId);
            return Ok(products.Select(p => p.ToProductDto()));
        }

        [HttpPost]
        [Authorize]
        [TypeFilter(typeof(ValidationFilter<CreateProductRequestDto>))]
        public async Task<IActionResult> Create([FromBody] CreateProductRequestDto productDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (!await _sellerRepo.SellerExists(productDto.SellerId))
                return BadRequest("Seller does not exist");

            var productModel = productDto.ToProductFromCreateDto();
            await _productRepo.CreateAsync(productModel);

            _logger.LogInformation("Created product {ProductId}", productModel.ProductId);

            return CreatedAtAction(nameof(GetById), new { id = productModel.ProductId }, productModel.ToProductDto());
        }

        [HttpPut("{id:int}")]
        [Authorize]
        [TypeFilter(typeof(ValidationFilter<UpdateProductRequestDto>))]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] UpdateProductRequestDto updateDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (!await _sellerRepo.SellerExists(updateDto.SellerId))
                return BadRequest("Seller does not exist");

            var product = await _productRepo.UpdateAsync(id, updateDto.ToProductFromUpdateDto());

            if (product == null)
            {
                return NotFound();
            }

            _cache.Remove(CacheKeys.ProductById(id));

            return Ok(product.ToProductDto());
        }

        [HttpDelete("{id:int}")]
        [Authorize]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            var product = await _productRepo.DeleteAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            _cache.Remove(CacheKeys.ProductById(id));
            _logger.LogInformation("Deleted product {ProductId}", id);

            return NoContent();
        }
    }
}
