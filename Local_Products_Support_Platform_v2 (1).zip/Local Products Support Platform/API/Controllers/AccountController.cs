using Local_Products_Support_Platform.Application.Dtos.Account;
using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Domain.Constants;
using Local_Products_Support_Platform.Domain.Entities.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Local_Products_Support_Platform.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly ITokenService _tokenService;

        public AccountController(UserManager<AppUser> userManager, ITokenService tokenService)
        {
            _userManager = userManager;
            _tokenService = tokenService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto registerDto)
        {
            var appUser = new AppUser()
            {
                Email = registerDto.Email,
                UserName = registerDto.Username
            };

            var createResult = await _userManager.CreateAsync(appUser, registerDto.Password);
            if (!createResult.Succeeded)
            {
                return BadRequest(createResult.Errors);
            }

            var roleResult = await _userManager.AddToRoleAsync(appUser, AppRoles.User);
            if (!roleResult.Succeeded)
            {
                return BadRequest(roleResult.Errors);
            }

            var roles = await _userManager.GetRolesAsync(appUser);
            return Ok(new NewUserDto
            {
                Username = appUser.UserName ?? "",
                Email = appUser.Email ?? "",
                Roles = roles,
                Token = _tokenService.CreateToken(appUser, roles)
            });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
        {
            var user = await _userManager.FindByNameAsync(loginDto.Username);

            if (user == null || !await _userManager.CheckPasswordAsync(user, loginDto.Password))
            {
                return Unauthorized("UserName or Password is incorrect");
            }

            var roles = await _userManager.GetRolesAsync(user);
            return Ok(new NewUserDto
            {
                Username = user.UserName ?? "",
                Email = user.Email ?? "",
                Roles = roles,
                Token = _tokenService.CreateToken(user, roles)
            });
        }
    }
}
