using Local_Products_Support_Platform.Domain.Constants;
using Local_Products_Support_Platform.Domain.Entities.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Local_Products_Support_Platform.Infrastructure.Data
{
    public class ApplicationDBContext : IdentityDbContext<AppUser>
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options)
            : base(options)
        {
        }

        public DbSet<Seller> Sellers { get; set; } = null!;
        public DbSet<Buyer> Buyers { get; set; } = null!;
        public DbSet<Product> Products { get; set; } = null!;
        public DbSet<Order> Orders { get; set; } = null!;
        public DbSet<OrderItem> OrderItems { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Product>()
                .HasOne(p => p.Seller)
                .WithMany(s => s.Products)
                .HasForeignKey(p => p.SellerId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<Order>()
                .HasOne(o => o.Buyer)
                .WithMany(b => b.Orders)
                .HasForeignKey(o => o.BuyerId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<OrderItem>()
                .HasOne(i => i.Order)
                .WithMany(o => o.OrderItems)
                .HasForeignKey(i => i.OrderId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<OrderItem>()
                .HasOne(i => i.Product)
                .WithMany(p => p.OrderItems)
                .HasForeignKey(i => i.ProductId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Seller>().HasData(
                new Seller
                {
                    SellerId = 1,
                    SellerName = "Rawan Abulmaaref",
                    SellerEmail = "rawan.abulmaaref@gmail.com",
                    SellerPhone = "01156959836",
                    SellerAddress = "Luxor,Armant"
                },
                new Seller
                {
                    SellerId = 2,
                    SellerName = "Hassan Mahmoud",
                    SellerEmail = "hassan.mahmoud@gmail.com",
                    SellerPhone = "01012345678",
                    SellerAddress = "Luxor,Gurna"
                });

            builder.Entity<Buyer>().HasData(
                new Buyer
                {
                    BuyerId = 1,
                    BuyerName = "Rawan",
                    BuyerEmail = "rawan.99@gmail.com",
                    BuyerPhone = "01198765432"
                });

            builder.Entity<Product>().HasData(
                new Product { ProductId = 1, ProductName = "Handmade Palm Basket", Price = 150.00m, SellerId = 1 },
                new Product { ProductId = 2, ProductName = "Pottery Water Jar", Price = 120.00m, SellerId = 1 },
                new Product { ProductId = 3, ProductName = "Alabaster Vase", Price = 450.00m, SellerId = 2 },
                new Product { ProductId = 4, ProductName = "Copper Tray", Price = 380.00m, SellerId = 2 });

            builder.Entity<Order>().HasData(
                new Order
                {
                    OrderId = 1,
                    Orderdate = new DateTime(2026, 10, 18),
                    Orderstatus = "Pending",
                    Totalprice = 300.00m,
                    BuyerId = 1
                });

            builder.Entity<OrderItem>().HasData(
                new OrderItem
                {
                    OrderItemId = 1,
                    OrderId = 1,
                    Quantity = 2,
                    UnitPrice = 150.00m,
                    ProductId = 1
                });

            builder.Entity<IdentityRole>().HasData(
                new IdentityRole
                {
                    Id = "76de869b-89d5-4da2-92da-770ec6875814",
                    Name = AppRoles.SuperAdmin,
                    NormalizedName = AppRoles.SuperAdmin.ToUpperInvariant(),
                    ConcurrencyStamp = "9cec3259-3278-4597-8f41-59ea57ba7384"
                },
                new IdentityRole
                {
                    Id = "4df3ea20-eb46-4504-859c-77909fda553f",
                    Name = AppRoles.Admin,
                    NormalizedName = AppRoles.Admin.ToUpperInvariant(),
                    ConcurrencyStamp = "d4c7490f-68b8-4599-8e21-b94eb999db3a"
                },
                new IdentityRole
                {
                    Id = "692f2a16-0ea9-4217-bae3-3531b130a19f",
                    Name = AppRoles.User,
                    NormalizedName = AppRoles.User.ToUpperInvariant(),
                    ConcurrencyStamp = "1b2be985-6149-4e19-ba2b-0cea06105bfa"
                });
        }
    }
}
