using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Domain.Entities.Models;
using Local_Products_Support_Platform.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Local_Products_Support_Platform.Infrastructure.Repository
{
    public class SellerRepository : ISellerRepository
    {
        private readonly ApplicationDBContext _context;

        public SellerRepository(ApplicationDBContext context)
        {
            _context = context;
        }

        public async Task<List<Seller>> GetAllAsync()
        {
            return await _context.Sellers.Where(s => !s.IsDelete).ToListAsync();
        }

        public async Task<Seller?> GetByIdAsync(int id)
        {
            return await _context.Sellers.FirstOrDefaultAsync(s => s.SellerId == id && !s.IsDelete);
        }

        public async Task<Seller> CreateAsync(Seller sellerModel)
        {
            await _context.Sellers.AddAsync(sellerModel);
            await _context.SaveChangesAsync();
            return sellerModel;
        }

        public async Task<Seller?> UpdateAsync(int id, Seller sellerModel)
        {
            var existingSeller = await GetByIdAsync(id);

            if (existingSeller == null)
            {
                return null;
            }

            existingSeller.SellerName = sellerModel.SellerName;
            existingSeller.SellerEmail = sellerModel.SellerEmail;
            existingSeller.SellerPhone = sellerModel.SellerPhone;
            existingSeller.SellerAddress = sellerModel.SellerAddress;

            await _context.SaveChangesAsync();
            return existingSeller;
        }

        public async Task<Seller?> DeleteAsync(int id)
        {
            var sellerModel = await GetByIdAsync(id);

            if (sellerModel == null)
            {
                return null;
            }

            sellerModel.IsDelete = true;

            var products = await _context.Products.Where(p => p.SellerId == id).ToListAsync();
            foreach (var product in products)
            {
                product.IsDelete = true;
            }

            await _context.SaveChangesAsync();
            return sellerModel;
        }

        public async Task<bool> SellerExists(int id)
        {
            return await _context.Sellers.AnyAsync(s => s.SellerId == id && !s.IsDelete);
        }
    }
}
