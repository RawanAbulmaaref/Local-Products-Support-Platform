using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Domain.Entities.Models;
using Local_Products_Support_Platform.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Local_Products_Support_Platform.Infrastructure.Repository
{
    public class BuyerRepository : IBuyerRepository
    {
        private readonly ApplicationDBContext _context;

        public BuyerRepository(ApplicationDBContext context)
        {
            _context = context;
        }

        public async Task<List<Buyer>> GetAllAsync()
        {
            return await _context.Buyers.Where(b => !b.IsDelete).ToListAsync();
        }

        public async Task<Buyer?> GetByIdAsync(int id)
        {
            return await _context.Buyers.FirstOrDefaultAsync(b => b.BuyerId == id && !b.IsDelete);
        }

        public async Task<Buyer> CreateAsync(Buyer buyerModel)
        {
            await _context.Buyers.AddAsync(buyerModel);
            await _context.SaveChangesAsync();
            return buyerModel;
        }

        public async Task<Buyer?> UpdateAsync(int id, Buyer buyerModel)
        {
            var existingBuyer = await GetByIdAsync(id);

            if (existingBuyer == null)
            {
                return null;
            }

            existingBuyer.BuyerName = buyerModel.BuyerName;
            existingBuyer.BuyerEmail = buyerModel.BuyerEmail;
            existingBuyer.BuyerPhone = buyerModel.BuyerPhone;

            await _context.SaveChangesAsync();
            return existingBuyer;
        }

        public async Task<Buyer?> DeleteAsync(int id)
        {
            var buyerModel = await GetByIdAsync(id);

            if (buyerModel == null)
            {
                return null;
            }

            buyerModel.IsDelete = true;
            await _context.SaveChangesAsync();
            return buyerModel;
        }

        public async Task<bool> BuyerExists(int id)
        {
            return await _context.Buyers.AnyAsync(b => b.BuyerId == id && !b.IsDelete);
        }
    }
}
