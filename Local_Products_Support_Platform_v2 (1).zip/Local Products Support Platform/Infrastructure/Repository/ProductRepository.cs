using Local_Products_Support_Platform.Application.Helpers;
using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Domain.Entities.Models;
using Local_Products_Support_Platform.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Local_Products_Support_Platform.Infrastructure.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDBContext _context;

        public ProductRepository(ApplicationDBContext context)
        {
            _context = context;
        }

        public async Task<List<Product>> GetAllAsync(QueryObject query)
        {
            var products = _context.Products.Where(p => !p.IsDelete).AsNoTracking().AsQueryable();

            if (!string.IsNullOrWhiteSpace(query.ProductName))
            {
                products = products.Where(p => p.ProductName.Contains(query.ProductName));
            }

            if (query.MinPrice.HasValue)
            {
                products = products.Where(p => p.Price >= query.MinPrice.Value);
            }

            if (query.MaxPrice.HasValue)
            {
                products = products.Where(p => p.Price <= query.MaxPrice.Value);
            }

            products = query.SortBy?.ToLower() switch
            {
                "productname" => query.IsDescending ? products.OrderByDescending(p => p.ProductName) : products.OrderBy(p => p.ProductName),
                "price" => query.IsDescending ? products.OrderByDescending(p => p.Price) : products.OrderBy(p => p.Price),
                _ => products.OrderBy(p => p.ProductId)
            };

            var skipNumber = (query.PageNumber - 1) * query.PageSize;

            return await products.Skip(skipNumber).Take(query.PageSize).ToListAsync();
        }

        public async Task<List<Product>> GetBySellerIdAsync(int sellerId)
        {
            return await _context.Products.Where(p => p.SellerId == sellerId && !p.IsDelete).ToListAsync();
        }

        public async Task<Product?> GetByIdAsync(int id)
        {
            return await _context.Products.FirstOrDefaultAsync(p => p.ProductId == id && !p.IsDelete);
        }

        public async Task<Product> CreateAsync(Product productModel)
        {
            await _context.Products.AddAsync(productModel);
            await _context.SaveChangesAsync();
            return productModel;
        }

        public async Task<Product?> UpdateAsync(int id, Product productModel)
        {
            var existingProduct = await GetByIdAsync(id);

            if (existingProduct == null)
            {
                return null;
            }

            existingProduct.ProductName = productModel.ProductName;
            existingProduct.Price = productModel.Price;
            existingProduct.SellerId = productModel.SellerId;

            await _context.SaveChangesAsync();
            return existingProduct;
        }

        public async Task<Product?> DeleteAsync(int id)
        {
            var productModel = await GetByIdAsync(id);

            if (productModel == null)
            {
                return null;
            }

            productModel.IsDelete = true;
            await _context.SaveChangesAsync();
            return productModel;
        }
    }
}
