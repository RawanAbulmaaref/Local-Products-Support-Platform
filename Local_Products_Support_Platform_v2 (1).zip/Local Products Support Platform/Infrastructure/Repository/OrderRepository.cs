using Local_Products_Support_Platform.Application.Interfaces;
using Local_Products_Support_Platform.Domain.Entities.Models;
using Local_Products_Support_Platform.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Local_Products_Support_Platform.Infrastructure.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDBContext _context;

        public OrderRepository(ApplicationDBContext context)
        {
            _context = context;
        }

        public async Task<List<Order>> GetAllAsync(int? buyerId = null)
        {
            var orders = _context.Orders.Include(o => o.OrderItems).AsQueryable();

            if (buyerId.HasValue)
            {
                orders = orders.Where(o => o.BuyerId == buyerId);
            }

            return await orders.ToListAsync();
        }

        public async Task<Order?> GetByIdAsync(int id)
        {
            return await _context.Orders.Include(o => o.OrderItems).FirstOrDefaultAsync(o => o.OrderId == id);
        }

        public async Task<Order> CreateAsync(Order orderModel)
        {
            await _context.Orders.AddAsync(orderModel);
            await _context.SaveChangesAsync();
            return orderModel;
        }

        public async Task<Order?> UpdateAsync(int id, Order orderModel)
        {
            var existingOrder = await GetByIdAsync(id);

            if (existingOrder == null)
            {
                return null;
            }

            existingOrder.Orderstatus = orderModel.Orderstatus;

            await _context.SaveChangesAsync();
            return existingOrder;
        }

        public async Task<Order?> DeleteAsync(int id)
        {
            var orderModel = await GetByIdAsync(id);

            if (orderModel == null)
            {
                return null;
            }

            _context.Orders.Remove(orderModel);
            await _context.SaveChangesAsync();
            return orderModel;
        }
    }
}
